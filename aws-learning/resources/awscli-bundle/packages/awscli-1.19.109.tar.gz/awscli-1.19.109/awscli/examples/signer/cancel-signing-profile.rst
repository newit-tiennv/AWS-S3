**To delete a signing profile**

The following ``cancel-signing-profile`` example removes an existing signing profile from AWS Signer. ::

    aws signer cancel-signing-profile \
        --profile-name MyProfile1

This command produces no output.
