**To delete a lexicon**

The following ``delete-lexicon`` example deletes the specified lexicon. ::

    aws polly delete-lexicon \
        --name w3c

This command produces no output.

For more information, see `Using the DeleteLexicon operation <https://docs.aws.amazon.com/polly/latest/dg/gs-delete-lexicon.html>`__ in the *Amazon Polly Developer Guide*.
