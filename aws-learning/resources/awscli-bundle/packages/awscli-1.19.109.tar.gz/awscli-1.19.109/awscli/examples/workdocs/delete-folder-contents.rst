**To delete the contents of a folder**

This example deletes the contents of the specified folder.

Command::

  aws workdocs delete-folder-contents --folder-id 26fa8aa4ba2071447c194f7b150b07149dbdb9e1c8a301872dcd93a4735ce65d

Output::

  None